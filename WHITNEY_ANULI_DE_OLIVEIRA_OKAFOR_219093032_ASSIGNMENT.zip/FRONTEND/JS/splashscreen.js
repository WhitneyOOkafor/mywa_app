// & this code makes the logo pulse andf then redirects the user to the login/signup
//& after an interval of 3 seconds
$(window).ready(window.setTimeout(function() {
    window.location.href = '../signupLogin/index.html';
}, 3000))